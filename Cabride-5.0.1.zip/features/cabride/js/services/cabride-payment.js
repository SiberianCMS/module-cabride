/**
 * CabridePayment service
 */
angular.module('starter')
    .service('CabridePayment', function () {
        var service = {

        };

        service.init = function () {

        };

        return service;
    });
