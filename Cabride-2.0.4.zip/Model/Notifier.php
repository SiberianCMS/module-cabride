<?php

namespace Cabride\Model;

use Core\Model\Base;

/**
 * Class Notifier
 * @package Cabride\Model
 *
 * @method integer getId()
 */
class Notifier extends Base
{
    public static function notifyPassenger($request)
    {

    }
}