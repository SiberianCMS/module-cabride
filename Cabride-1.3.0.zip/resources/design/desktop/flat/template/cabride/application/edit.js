/**
 * Default JS for new module!
 */
$(document).ready(function () {
    bindForms('#cabride');
});
